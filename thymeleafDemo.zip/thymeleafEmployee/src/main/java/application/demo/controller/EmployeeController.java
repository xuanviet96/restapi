package application.demo.controller;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import application.demo.model.Employee;

@Controller
@RequestMapping("/employees")
public class EmployeeController {
	private EmployeeDaoService employeeDaoService;
	
	public EmployeeController(EmployeeDaoService employeeDaoService) {
		this.employeeDaoService = employeeDaoService;
	}
	
	//add mapping for "/list"
	@GetMapping("/list")
	public String listEmployees(Model theModel) {
		//add to the spring model
		theModel.addAttribute("employees", employeeDaoService.getAllEmployees());
		return "list-employees";
	}
	
	@GetMapping("/form-add")
	  public String employeeForm(Model model) {
		Employee employee = new Employee();
	    model.addAttribute("employee", employee);
	    return "form";
	  }

	 @PostMapping("/form-add")
	  public String employeeSubmitFormAdd(@ModelAttribute("employee") Employee employee) {
		  System.out.println(employee);
		    return "result";
	  }
	 
	 @GetMapping("/form-edit")
	  public String employeeForm(@RequestParam(value = "id", required = false) Integer id, Model model) {
		//Employee employee = new Employee();
		Employee employee = employeeDaoService.findById(id);
	    model.addAttribute("employee", employee);
	    return "form-edit";
	  }
	 @PostMapping("/form-edit")
	  public String employeeSubmitFormEdit(@ModelAttribute("employee") Employee employee) {
		  System.out.println(employee);
		    return "result";
	  }

}
