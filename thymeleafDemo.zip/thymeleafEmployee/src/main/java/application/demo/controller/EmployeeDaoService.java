package application.demo.controller;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Predicate;

import org.springframework.stereotype.Component;

import application.demo.model.Employee;

import application.demo.model.Employee;

@Component
public class EmployeeDaoService {
	// JPA/Hibernate > Database
	// UserDaoService > Static List
	
	private static List<Employee> theEmployees = new ArrayList<>();
	
	private static int employeesCount = 0;
	
	static {
		theEmployees.add(new Employee(++employeesCount, "Andrew", "Xuan", "xuan.andrew@gmail,com"));
		theEmployees.add(new Employee(++employeesCount, "Luk", "Shaw", "shaw.luk@gmail,com"));
		theEmployees.add(new Employee(++employeesCount, "Andree", "Sara", "sara.andree@gmail,com"));
	}
	
	public List<Employee> getAllEmployees() {  
	    return theEmployees;  
	  }  
	
	public Employee findById(int id) { 
			Predicate<? super Employee> predicate = user -> user.getId() == id; 
			return theEmployees.stream().filter(predicate).findFirst().orElse(null);
		}

	//SAME_OLD_CODE
}