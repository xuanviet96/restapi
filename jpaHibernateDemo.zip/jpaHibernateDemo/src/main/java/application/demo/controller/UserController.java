package application.demo.controller;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import application.demo.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

//import application.demo.exception.UserNotFoundException;
import application.demo.model.User;
import application.demo.repository.UserRepository;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/users")
public class UserController {
	int numberPerPage = 10;

	UserService userService = new UserService();

	public int countPages(int numberPerPage){
		if(userService.findAllUsers().size() % numberPerPage != 0){
			return userService.findAllUsers().size() / numberPerPage +1;
		}
		return userService.findAllUsers().size() / numberPerPage;
	}
	public List


//	 void constructor() {
//	 	this.totalUser = this.userService.findAllUsers().size();
//	 }

//	@GetMapping("/all")
//	public List<User> listAll(){
//		return (List<User>) userService.findAll();
//	}
	@GetMapping("register")
	public String employeeForm() {

		return "index";
	  }

	//add mapping for "/list"
	@GetMapping({"/list"})
	public String userList(Model theModel) {

		//To do
		User[] usersInPage = userService.findAllUsers().toArray(new User[0]);
		theModel.addAttribute("users", usersInPage);
		theModel.addAttribute("pages", countPages(numberPerPage));
		return "list-user";
	}

	@GetMapping({"/list/{page}"})
	public String userList(@PathVariable Integer page, Model theModel) {

		//add to the spring model

		User[] users = userService.findAllUsers().toArray(new User[0]);
		int skip = users.length / numberPerPage +1;
		User[] usersPerPage = Arrays.copyOfRange(users, (page-1) * numberPerPage +1, page * numberPerPage -1);
		theModel.addAttribute("users", usersPerPage);
		return "list-user";
	}


	@GetMapping("/import")
	public String importT(Model theModel) {
		User user;
		for(Integer i=0; i< 100; i++){
			user = new User(i, "Xuan"+i.toString(), 	"abn", "xuan@gmail.com");
			this.userService.save(user);
		}
		return "welcome";
	}

	@PostMapping("/register")
	public String userRegistration(@ModelAttribute User user, Model model) {
		System.out.println(user.toString());
		System.out.println(user.getFirstName());
		System.out.println(user.getLastName());
		System.out.println(user.getEmail());

//		User user_inserted = userService.findUserById(user.getId());
		
//		User user_existed = userRepository.find(user.getId());
		
		this.userService.save(user);
		model.addAttribute("message", user.getEmail() + " inserted");
		return "welcome";
	}
	 
	 //using path variable
	 @GetMapping("/edit/{id}")
	  public String employeeGetFormById(@PathVariable Integer id, Model model) {

		 // TODO: check if user existed then update info else throw not found
//		 boolean user_existed = userService.get(id);
//		 if (!user_existed) {
//			 // TODO: throw new Error
//			 System.out.println("User Not Found");
//			 return "user-not-found";
//		 }
		User user = this.userService.get(id);
		model.addAttribute("user", user);
	    return "form-edit";
	  }
	 
	 @PostMapping("/edit/{id}")
	 public String userSubmitFormEdit(@PathVariable Integer id, @ModelAttribute("user") User user, Model model) {
		 
		System.out.println(id);

		// TODO: save user with new information
		 //

		User user_inserted = this.userService.findUserById(user.getId());
		this.userService.save(user);
		
		// TODO: .....
		model.addAttribute("message", user_inserted.getEmail() + " modified");
		return "welcome";
	  }

	  @PostMapping("/delete/{id}")
	public ModelAndView deleteUserByIdUsingPostMethod(@PathVariable Integer id, ModelMap model){
		  this.userService.delete(id);
		return new ModelAndView("redirect:/users/list", model);
	  }
//	  @PostMapping
//	public String deleteById(@PathVariable Integer id, Model model){
//		  userRepository.deleteById(id);
//		  return this.userList(model);
//	  }


}
